Read_Me for assignement 5

Bayley King

There were 3 libraries used in this code (which is in python 3.6).....

csv
random
numpy

network.py is the full network for both problems. At the bottom of the file, I have two commented lines of code that mark what needs to be uncommented to read in the testing data set for problem #2. I included the txt files of each data set in a zip folder along with a file neamed weights.txt. This isn't needed to run, this is just for when I was solely testing in problem 2. if you comment out the line that calls for the training function to run, then the network will load in the weights from this file instead. 

If you have any questions, please reach out to me. 

king2b3@mail.uc.edu
